//Basic Component
import React from 'react';

//Router
import { BrowserRouter as Router, Route } from 'react-router-dom';

//Custom CSS
import './App.css';

//Custom Component
import Home from './Pages/Home/Home';
import About from './Pages/About Us/About us';
import Contact from './Pages/Contact Us/Contact us';
import Login from './Components/Login/Login';
import Singapore from './Country Components/Singapore/SIngapore';
import Malaysia from './Country Components/Malaysia/Malaysia';
import Bangkok from './Country Components/Bangkok/Bangkok';
import Azerbaijan from './Country Components/Azerbaijan/Azerbaijan';


// import LoginSide from './Components/Login/Login side';

class App extends React.Component {
  render() {
    return (
      <div className="App">
        <Router>

          <switch>

            <Route path='/' exact component={Home} />
            <Route path='/login' component={Login} />
            <Route path='/About' component={About} />
            <Route path='/Contact' component={Contact} />
            <Route path='/Singapore' component={Singapore} />
            <Route path='/Malaysia' component={Malaysia} />
            <Route path='/Bangkok' component={Bangkok} />
            <Route path='/Azerbaijan' component={Azerbaijan} />

          </switch>

        </Router>
      </div>
    )
  };
}
export default App;
