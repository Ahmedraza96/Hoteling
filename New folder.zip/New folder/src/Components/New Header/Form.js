//Basic Component
import React, { Component } from "react";
import './Form.css'
import { Link } from 'react-router-dom';

//Custom Components
import Singapore from '../../Country Components/Singapore/SIngapore.js'

class Form extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            Singapore: '',
            Malaysia: '',
            Bangkok: '',
            Azerbaijan: '',
            dateFrom: '',
            dateTo: '',
            adult: '',
            child: '',
        };
    }
    // handleChange = event => {
    //     this.setState({ adult: event.target.value });    

    handleChange = ev => {
        const { name, value } = ev.target;
        this.setState({
            [name]: value,
        });
    }

    handleSubmit = event => {
        console.log('A journey booking: ' + this.state.Singapore + this.state.dateFrom + this.state.dateTo + this.state.adult + this.state.child);
        event.preventDefault();
        // switch (this.state) {
        //     case "Singapore" : 
        //         //  return <Singapore />
        //     window.location.assign("/Singapore")
        //         break
        //     case "Malaysia":   return <h1>Hello Mal</h1>
        //         break
        //     case "Bangkok": return <h1>Hello Mal</h1>
        //         break
        //     case "Azerbaijan":  return <h1>Hello Mal</h1>
        //         break
            
        //     default: return console.log('No project match')
        // }
        window.location.assign("/Singapore")
    };

    render() {
        const {
            Singapore, Malaysia, Bangkok, Azerbaijan, dateFrom, dateTo, adult, child } = this.state;
        console.log(this.state.Singapore + this.state.value)
        return (
            <div className="Form">
                <form onSubmit={this.handleSubmit}>
                    <div>
                        <label>
                            Country:
                        <select name="country" className='country'>
                                <option name="Singapore" value={Singapore}>Singapore</option>
                                <option value={Malaysia}>Malaysia</option>
                                <option value={Bangkok}>Bangkok</option>
                                <option value={Azerbaijan}>Azerbaijan</option>
                                onChange={this.handleChange}
                            </select>
                        </label>
                    </div>

                    <div className='date'>
                        <label>
                            Date From :
                             <input type="date" min="2019-11-11"
                                name='dateFrom' value={dateFrom}
                                onChange={this.handleChange}
                            >
                            </input>
                        </label>
                        <label>
                            Date To :
                            <input type="date" min="2019-11-12"
                                name='dateTo' value={dateTo}
                                onChange={this.handleChange}
                            >
                            </input>
                        </label>
                    </div>

                    <div>
                        <label className='qty'>
                            Adult:
                           <input type="number" name="quantity" min="1"
                                className='person'
                                name='adult' value={adult}
                                onChange={this.handleChange}
                            >
                            </input>
                        </label>
                        <label className='qty'>
                            Child:
                           <input type="number" name="quantity" min="1"
                                className='person'
                                name='child' value={child}
                                onChange={this.handleChange}
                            >
                            </input>
                        </label>
                    </div>
                    <input type="submit" value="Execute" className='Execute' />
                </form>
            </div>
        );
    }
}

export default Form;