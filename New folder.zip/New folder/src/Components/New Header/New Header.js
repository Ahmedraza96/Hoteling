import React from 'react';
import './style.css'

import Form from './Form'

class New extends React.Component {
    render() {
        return (
            <div className="Main1">
                {/* <!-- Header --> */}
                <header id="header1" className="alt">
                    <div className="logo"><a href="index.html">Taiba Aviation <span>enjoy journey</span></a></div>
                    <a href="#menu" className="toggle"><span>Menu</span></a>
                </header>

                {/* <!-- Nav --> */}
                <nav id="menu">
                    <ul className="links">
                        <li><a href="index.html">Home</a></li>
                        <li><a href="generic.html">Generic</a></li>
                        <li><a href="elements.html">Elements</a></li>
                    </ul>
                </nav>

                {/* <!-- Banner --> */}
                <section id="full" data-video="images/banner">
                    <div className="inner">
                            <Form />
                        {/* <a href="#one" className="button special scrolly">Get Started</a> */}
                    </div>
                </section>

            </div>
        );
    }
}

export default New;