import React from 'react';

// import css from './fontawesome-all.min'
import './style.css'

//import Link
import { Link } from 'react-router-dom';


class Header extends React.Component {
    render() {
        return (
            <div id="header-wrapper">
                <header id="header" className="container">

                    {/* <!-- Logo --> */}
                    <div id="logo">
                        <h1><Link to="">Taiba Aviation</Link></h1>
                        <span></span>
                    </div>

                    {/* <!-- Nav --> */}
                    <nav id="nav">
                        <ul>
                            <li className="current"><Link to="">Welcome</Link></li>
                            <li>
                                <a href="#">Dropdown</a>
                                <ul>
                                    <li><a href="#">Lorem ipsum dolor</a></li>
                                    <li><a href="#">Magna phasellus</a></li>
                                    <li>
                                        <a href="#">Phasellus consequat</a>
                                        <ul>
                                            <li><a href="#">Lorem ipsum dolor</a></li>
                                            <li><a href="#">Phasellus consequat</a></li>
                                            <li><a href="#">Magna phasellus</a></li>
                                            <li><a href="#">Etiam dolore nisl</a></li>
                                        </ul>
                                    </li>
                                    <li><a href="#">Veroeros feugiat</a></li>
                                </ul>
                            </li>
                            <li><Link to="About">About Us</Link></li>
                            <li><Link to="Contact">Contact</Link></li>
                            <li><Link to="/login">Login</Link></li>
                        </ul>
                    </nav>

                </header>
            </div>
        )
    };

}

export default Header;