//Basic Component
import React, { Component } from "react";
import PropTypes from 'prop-types';

//Material-UI Component
import {
    Avatar, CssBaseline, FormControlLabel, Checkbox, Link, Paper,
    Grid, Typography, Button, TextField, FormControl, InputLabel,
    Select, OutlinedInput, CircularProgress, makeStyles

} from '@material-ui/core'

import LockOutlinedIcon from '@material-ui/icons/LockOutlined';

class LoginSide extends Component {
    constructor() {
        super();
        this.state = {
            email: '',
            password: '',
            confirmPassword: '',
            father: '',
            first: '',
            last: '',
            dob: '',
            position: '',
            gender: '',
            isLoading: false,
            isSignIn: true,
            open: false,
            message: '',
        }
    }

    // componentDidMount() {
    //   this.setState({ isLoading: true })
    //   firebase.auth().onAuthStateChanged(user => {
    //     if (user) {
    //       const uid = user.uid;
    //       localStorage.setItem('uid', JSON.stringify(uid));
    //       this.props.history.replace('/dashboard');
    //     }
    //     else {
    //       this.setState({ isLoading: false })
    //     }
    //   });
    // }

    handleChange = ev => {
        const { name, value } = ev.target;
        this.setState({
            [name]: value,
        });
    }

    onLoginChange = () => {
        this.setState(state => ({
            isSignIn: !state.isSignIn,
        }));
    }

    onError = (isLoading, open, message) => {
        this.setState({ isLoading, open, message });
    }

    onLoginHandler = () => {
        this.setState({ isLoading: true })
        let {
            isSignIn,
            email, password, confirmPassword,
            father, first, last, dob, position, gender
        } = this.state;
        let uid = '';
        if (email.indexOf('@') !== -1 && email.indexOf('.com') !== -1) {
            if (password.length >= 6) {
                // if (isSignIn) {
                //   firebase.auth().signInWithEmailAndPassword(email, password)
                // .then(resp => {
                // uid = resp.user.uid;
                this.setState({ isLoading: true })
                localStorage.setItem('uid', JSON.stringify(uid));
                this.props.history.replace('/dashboard');
            }
            // .catch(error => {
            //   this.onError(false, true, error.message);
            // })
        }
        else {
            if (password === confirmPassword) {
                // firebase.auth().createUserWithEmailAndPassword(email, password)
                //   .then(resp => {
                //     uid = resp.user.uid;
                //     firebase.database().ref().child('profile').child(uid).set({
                //       father, first, last, dob, position, gender, uid
                //     })
                // email = password = confirmPassword = father = first = last = dob = position = gender = '';
                this.setState({
                    isSignIn: true,
                    email, password,
                    confirmPassword, father, first, last, dob, position, gender,
                    open: true,
                    message: 'Email ID made successfully...',
                });
            }
            // .catch(error => {
            //   this.onError(false, true, error.message);
            // })
        }
        //         else {
        //           this.onError(false, true, 'Confirm password must be equivalent to the password.');
        //         }
        //       }
        //     }
        //     else {
        //       this.onError(false, true, 'Password length must atleast be six (06) character long.');
        //     }
        //   }
        //   else {
        //     this.onError(false, true, 'The Address must contain "@" & ".com" in email.');
        //   }
        // }

        // // handleCloseMessage = () => {
        // //   this.setState({
        // //     open: false,
        // //   });
        // }
    }
    render() {
        const {
            isSignIn, isLoading,
            email, password,
            confirmPassword, father, first, last, dob, position, gender,
            open, message
        } = this.state;
        const { classes } = this.props;
        if (isLoading) {
            return (
                <div
                    className={classes.flexBox}
                    style={{ height: '100vh' }}
                >
                    <CircularProgress />
                </div>
            );
        }
        else {
            return (
                <Grid container component="main" className={classes.root}>
                    <CssBaseline />
                    <Grid item xs={false} sm={4} md={7} className={classes.image} />
                    <Grid item xs={12} sm={8} md={5} component={Paper} elevation={6} square>
                        <div className={classes.paper}>
                            <Avatar className={classes.avatar}>
                                <LockOutlinedIcon />
                            </Avatar>
                            <Typography component="h1" variant="h5">
                                Sign in
                            </Typography>
                            <form className={classes.form} noValidate>
                                <TextField
                                    variant="outlined"
                                    margin="normal"
                                    required
                                    fullWidth
                                    id="email"
                                    label="Email Address"
                                    name="email"
                                    autoComplete="email"
                                    autoFocus
                                />
                                <TextField
                                    variant="outlined"
                                    margin="normal"
                                    required
                                    fullWidth
                                    name="password"
                                    label="Password"
                                    type="password"
                                    id="password"
                                    autoComplete="current-password"
                                />

                                {isSignIn ? '' : (
                                    <div>
                                        <TextField
                                            margin='normal'
                                            fullWidth={true}
                                            placeholder='Please Enter'
                                            variant='outlined'
                                            label='Confirm Password'
                                            type='password'
                                            name='confirmPassword' value={confirmPassword}
                                            onChange={this.handleChange} />
                                        <TextField
                                            margin='normal'
                                            fullWidth={true}
                                            placeholder='Please Enter'
                                            variant='outlined'
                                            label="First Name"
                                            type='text'
                                            name='first' value={first}
                                            onChange={this.handleChange} />
                                        <TextField
                                            margin='normal'
                                            fullWidth={true}
                                            placeholder='Please Enter'
                                            variant='outlined'
                                            label="Last Name"
                                            type='text'
                                            name='last' value={last}
                                            onChange={this.handleChange} />
                                        <TextField
                                            margin='normal'
                                            fullWidth={true}
                                            placeholder='Please Enter'
                                            variant='outlined'
                                            label="Father's Name"
                                            type='text'
                                            name='father' value={father}
                                            onChange={this.handleChange} />
                                        <TextField
                                            margin='normal'
                                            fullWidth={true}
                                            placeholder='Please Enter'
                                            variant='outlined'
                                            label="Position"
                                            type='text'
                                            name='position' value={position}
                                            onChange={this.handleChange} />
                                        <TextField
                                            margin='normal'
                                            fullWidth={true}
                                            placeholder='Please Enter'
                                            variant='outlined'
                                            label="Date of Birth"
                                            InputLabelProps={{ shrink: true }}
                                            type='date'
                                            name='dob' value={dob}
                                            onChange={this.handleChange} />

                                        <FormControlLabel
                                            control={<Checkbox value="remember" color="primary" />}
                                            label="Remember me"
                                        />
                                        <FormControl
                                            variant='outlined'
                                            fullWidth={true}
                                            margin='normal'
                                        >
                                            <InputLabel
                                                htmlFor="filled-gender-native-simple"
                                            >
                                                Gender
                                  </InputLabel>
                                            <Select
                                                native
                                                value={gender}
                                                onChange={this.handleChange}
                                                input={
                                                    <OutlinedInput
                                                        labelWidth={55}
                                                        name="gender"
                                                        id="filled-gender-native-simple"
                                                    />}
                                            >
                                                <option value="" />
                                                <option value='Male'>Male</option>
                                                <option value='Female'>Female</option>
                                            </Select>
                                        </FormControl>
                                    </div>
                                )}
                            <Button
                                type="submit"
                                fullWidth
                                variant="contained"
                                color="primary"
                                className={classes.submit}
                                onClick={this.onLoginHandler} >
                                {isSignIn ? 'Sign In' : 'Sign Up & Login'}
                            </Button>

                            <Grid container>
                                <Grid item>
                                    <Link href="#" variant="body2">
                                        {"Don't have an account? Sign Up"}
                                    </Link>
                                </Grid>
                            </Grid>
                        </form>
                        </div>
                    </Grid>
                </Grid>
            );
        }
    }
}

{/* <Button
style={{ marginLeft: 15 }}
variant='text'
color="secondary"
onClick={this.onLoginChange}
>
{isSignIn ? 'Sign Up' : 'Sign In'}
</Button> */}
{/* <PositionedSnackbar
open={open}
message={message}
close={this.handleCloseMessage}
/> */}

const useStyles = makeStyles(theme => ({
    root: {
        height: '100vh',
    },
    image: {
        backgroundImage: 'url(https://source.unsplash.com/random)',
        backgroundRepeat: 'no-repeat',
        backgroundSize: 'cover',
        backgroundPosition: 'center',
    },
    paper: {
        margin: theme.spacing(8, 4),
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
    },
    avatar: {
        margin: theme.spacing(1),
        backgroundColor: theme.palette.secondary.main,
    },
    form: {
        width: '100%', // Fix IE 11 issue.
        marginTop: theme.spacing(1),
    },
    submit: {
        margin: theme.spacing(3, 0, 2),
    },
}));


LoginSide.propTypes = {
    classes: PropTypes.object.isRequired,
};



export default useStyles(makeStyles)(LoginSide);