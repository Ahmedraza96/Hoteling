//Basic Component
import React from 'react';


//Custom Component
import Header from '../../Components/Header/Header'
import Footer from '../../Components/Footer/Footer'




class Bangkok extends React.Component {
    render() {
        return (
            <div className='Bangkok'>
                <Header />
                <h1>Bangkok</h1>

                <div>

                <img src={require('./Images/Shangri-La Hotel Bangkok.jpg')}/>
                    <h1>Shangri-La Hotel Bangkok</h1>

                    <p>Bang Rak, Bangkok</p>
                    <p>Located along the Chao Phraya River, Shangri-La Hotel Bangkok features a 10,000-sqm Fitness Center and the multi-awarded CHI, The Spa at Shangri-La.</p>

                    <div>
                        <button>Book</button>
                    </div>

                </div>

                <div>

                <img src={require('./Images/Emporium Suites by Chatrium.jpg')}/>
                    <h1>Emporium Suites by Chatrium</h1>

                    <p>Khlong Toei, Bangkok</p>
                    <p>Renovated in 2019, Emporium Suites by Chatrium offers luxurious accommodations directly connected to Phrom Phong BTS Station.</p>

                    <div>
                        <button>Book</button>
                    </div>

                </div>

                <div>

                <img src={require('./Images/Somerset Sukhumvit Thonglor.jpg')}/>
                    <h1>Somerset Sukhumvit Thonglor</h1>

                    <p>Wattana, Bangkok</p>
                    <p>Located in Soi Thonglor, Somerset Sukhumvit Thonglor features accommodations with fully equipped kitchenettes. Facilities include an outdoor swimming pool, a fitness center and free parking.</p>
                    <div>
                        <button>Book</button>
                    </div>

                </div>

                <div>

                <img src={require('./Images/The Heritage Bangkok.jpg')}/>
                    <h1>The Heritage Bangkok</h1>

                    <p>Bang Rak, Bangkok</p>
                    <p>A one-minute walk from Chong Nonsi BTS Skytrain Station, The Heritage Bangkok offers rooms with free WiFi access.</p>
                    <div>
                        <button>Book</button>
                    </div>

                </div>

                <div>

                <img src={require('./Images/Centara Grand At Centralworld.jpg')}/>
                    <h1>Centara Grand At Centralworld</h1>

                    <p>Pathumwan, Bangkok</p>
                    <p>The luxurious Centara Grand At CentralWorld is located in Pathumwan, a 10-minute stroll from Chidlom BTS Skytrain Station. Big on Thai hospitality, it offers an outdoor pool and 9 dining options.</p>
                        <div>
                            <button>Book</button>
                        </div>

                </div>
                <Footer />


            </div >

                    )
                };
            }
            
export default Bangkok;