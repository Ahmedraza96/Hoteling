//Basic Component
import React from 'react';


//Custom Component
import Header from '../../Components/Header/Header'
import Footer from '../../Components/Footer/Footer'



class Singapore extends React.Component {
    render() {
        return (
            <div className='Singapore'>
                <Header />
                <h1>Singapore</h1>

                <div>

                    <img src={require('./Images/Destination Singapore Beach Road.jpeg')} />
                    <h2>Destination Singapore Beach Road</h2>

                    <p>Kallang, Singapore</p>
                    <p>Located along Beach Road just minutes away from the culturally vibrant district of Kampong Glam, Destination Singapore Beach Road offers accommodations in Singapore.Booked 10 times in the last 6 hours.</p>

                    <div>
                        <button>Book</button>
                    </div>

                </div>

                <div>

                    <img src={require('./Images/Mandarin Orchard Singapore.jpg')} />
                    <h1>Mandarin Orchard Singapore </h1>

                    <p>Orchard, Singapore</p>
                    <p>Located along Beach Road just minutes away from the culturally vibrant district of Kampong Glam, Destination Singapore Beach Road offers accommodations in Singapore.Booked 10 times in the last 6 hours.</p>

                    <div>
                        <button>Book</button>
                    </div>

                </div>

                <div>

                    <img src={require('./Images/Pan Pacific Singapore.jpg')} />
                    <h1>Pan Pacific Singapore</h1>

                    <p>Marina Bay, Singapore</p>
                    <p>The 5-star Pan Pacific Singapore is directly connected to Marina Square Mall and Suntec Convention Center.</p>
                    <div>
                        <button>Book</button>
                    </div>

                </div>

                <div>

                    <img src={require('./Images/Carlton Hotel Singapore.jpg')} />
                    <h1>Carlton Hotel Singapore</h1>

                    <p>City Hall, Singapore</p>
                    <p>Strategically located in the heart of City Hall along Bras Basah Road, Carlton Hotel offers accommodations in Singapore.</p>
                    <div>
                        <button>Book</button>
                    </div>

                </div>

                <div>

                    <img src={require('./Images/YOTEL Singapore Orchard Road.jpg')} />
                    <h1>YOTEL Singapore Orchard Road</h1>

                    <p>Orchard, Singapore</p>
                    <p>Located in the heart of the vibrant Orchard Road district, YOTEL Singapore Orchard Road offers smoke-free accommodations in Singapore.</p>
                    <div>
                        <button>Book</button>
                    </div>

                </div>
                <Footer />


            </div >

        )
    };
}

export default Singapore;