//Basic Component
import React from 'react';


//Custom Component
import Header from '../../Components/Header/Header'
import Footer from '../../Components/Footer/Footer'




class Malaysia extends React.Component {
    render() {
        return (
            <div className='Malaysia'>
                <Header />
                <h1>Malaysia</h1>

                <div>

                    <img src={require('./Images/Empire Hotel Subang.jpg')} />
                    <h1>Empire Hotel Subang </h1>

                    <p>Subang Jaya</p>
                    <p>Stylishly designed, Empire Hotel Subang features 3 dining options and free WiFi throughout the property. Complimentary drop-off to Sunway Pyramid and Sunway Lagoon is also available.</p>

                    <div>
                        <button>Book</button>
                    </div>

                </div>

                <div>

                    <img src={require('./Images/The Andaman, a Luxury Collection Resort, Langkawi.jpg')} />
                    <h1>The Andaman, a Luxury Collection Resort, Langkawi</h1>

                    <p>Teluk Datai</p>
                    <p>The Andaman, a Luxury Collection Resort, Langkawi is nestled in the lush rainforest with panoramic sea views and a private beach.</p>

                    <div>
                        <button>Book</button>
                    </div>

                </div>

                <div>

                    <img src={require('./Images/Le Meridien Putrajaya.jpg')} />
                    <h1>Le Meridien Putrajaya</h1>

                    <p>Putrajaya</p>
                    <p>Located in Putrajaya, Le Meridien Putrajaya offers accommodations in Kuala Lumpur. It features an outdoor swimming pool and guests can enjoy meals at 3 of the property's dining options.</p>
                    <div>
                        <button>Book</button>
                    </div>

                </div>

                <div>

                    <img src={require('./Images/Holiday Villa Hotel & Suites Subang.jpg')} />
                    <h1>Holiday Villa Hotel & Suites Subang </h1>

                    <p>Subang Jaya</p>
                    <p>A15-minute drive from Sunway Pyramid and The Summit, Holiday Villa offers 9 dining options and an Olympic-sized pool. It also features squash and tennis courts.</p>
                    <div>
                        <button>Book</button>
                    </div>

                </div>

                <div>

                    <img src={require('./Images/Somerset Medini Iskandar Puteri.jpg')} />
                    <h1>Somerset Medini Iskandar Puteri</h1>

                    <p>Nusajaya</p>
                    <p>Located 2133 feet from LEGOLAND Malaysia, Somerset Medini Iskandar Puteri offers modern, air-conditioned apartments in Johor Bahru.</p>
                    <div>
                        <button>Book</button>
                    </div>

                </div>

                <Footer />
            </div >

        )
    };
}

export default Malaysia;