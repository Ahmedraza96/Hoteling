//Basic Component
import React from 'react';


//Custom Component
import Header from '../../Components/Header/Header'
import Footer from '../../Components/Footer/Footer'




class Azerbaijan extends React.Component {
    render() {
        return (
            <div className='Azerbaijan'>
                <Header />
                <h1>Azerbaijan</h1>

                <div>

                <img src={require('./Images/Hilton Baku.jpg')}/>
                    <h1>Hilton Baku</h1>

                    <p>Azadlig Ave, Baku</p>
                    <p>Beautiful Views Of The Caspian Sea Located in Baku’s fashionable area. 3 minutes from Baku boulevard and 10 minutes walk from Old City. Ideally located for shopping.</p>
                    <div>
                        <button>Book</button>
                    </div>

                </div>

                <div>

                <img src={require('./Images/Premier Old Gates.jpg')}/>
                    <h1>Premier Old Gates</h1>

                    <p>Kichik Gala Street, Baku</p>
                    <p>In Baku Old Town Fountain Square - 13 min walk Baku City Circuit - 1 min walk Flarmoniya Park - 1 min walk Palace of the Shirvan Shahs - 4 min walk Azerbaijan State Philharmonic Hall - 5 min walk Maiden's Tower - 5 min walk Caspian Sea - 7 min walk.</p>
                    <div>
                        <button>Book</button>
                    </div>

                </div>

                <div>

                <img src={require('./Images/Fairmont Baku, Flame Towers.jpg')}/>
                    <h1>Fairmont Baku, Flame Towers</h1>

                    <p> Mehdi Huseyn Str, Sebail District, Flame Towers, Baku</p>
                    <p>318 smoke-free guestrooms Restaurant and 3 bars/lounges Full-service spa Indoor pool and outdoor pool Breakfast available Health club Business center Airport shuttle. Azerbaijan State Philharmonic Hall (6-minute walk) Palace of the Shirvan Shahs (9-minute walk).</p>
                    <div>
                        <button>Book</button>
                    </div>

                </div>

                <div>

                <img src={require('./Images/Excelsior Hotel & Spa Baku.jpg')}/>
                    <h1>Excelsior Hotel & Spa Baku</h1>

                    <p>Heydar Aliyev Avenue, Baku</p>
                    <p>61 smoke-free guestrooms 2 restaurants and 2 poolside bars Full-service spa Indoor pool and 2 spa tubs Breakfast available Free area shuttle Health club. Haydar Aliyev Cultural Center - 6 min walk Metro Park - 21 min walk Baku City Circuit - 26 min walk.</p>
                    <div>
                        <button>Book</button>
                    </div>

                </div>

                <div>

                <img src={require('./Images/Passage Boutique Hotel.jpg')}/>
                    <h1>Passage Boutique Hotel</h1>

                    <p>Nizami Street 49, Baku</p>
                    <p>Restaurant and bar/lounge Airport shuttle Terrace 24-hour front desk Coffee/tea in a common area Air conditioning Daily housekeeping Front desk safe.Maiden's Tower (6-minute walk) Azerbaijan State Philharmonic Hall (8-minute walk)</p>
                    <div>
                        <button>Book</button>
                    </div>

                </div>
                <Footer />


            </div >

        )
    };
}

export default Azerbaijan;