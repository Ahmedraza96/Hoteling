import React, { Component } from "react";
import './Style.css';

//Custom Component
import Header from '../../Components/Header/Header'
import Footer from '../../Components/Footer/Footer'


class Contact extends React.Component {
    render() {
        return (
            <div className="">
            <Header />
                <div className="content Main">
                    <h1>Contact Us</h1>
                    <p>You can contact us for detail of our different packages.</p>
                    <p>Contact info</p>
                    <p>Phone: +92213-4551570-1, +92335-2176859</p>
                    <p>Email us: info@taibaaviation.com</p>
                    <p>Address: Bungalow No 161-A PECHS Block 3 Sir Syed Road Karachi</p>
                </div>
                <Footer />
            </div>
        );
    }
}

export default Contact;