//Basic Component
import React, { Component } from "react";

//Custom Component
import Header from '../../Components/Header/Header';
import Banner from '../../Components/Banner/Banner';
import Features from '../../Components/Features/Features';
import Main from '../../Components/Main/Main';
import Footer from '../../Components/Footer/Footer';
import New from '../../Components/New Header/New Header';


class Home extends React.Component {
    render() {
        return (
            <div id="">
                <New />
                {/* <Header /> */}
                <Banner />
                <Features />
                <Main />
                <Footer />
            </div>
        );
    }
}

export default Home;